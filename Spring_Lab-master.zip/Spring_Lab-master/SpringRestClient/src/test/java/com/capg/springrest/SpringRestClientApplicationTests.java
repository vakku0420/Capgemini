package com.capg.springrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
